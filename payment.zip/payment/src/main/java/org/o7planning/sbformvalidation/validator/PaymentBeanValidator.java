package org.o7planning.sbformvalidation.validator;

import org.apache.commons.validator.routines.EmailValidator;
import org.o7planning.sbformvalidation.dao.PaymentDAO;
import org.o7planning.sbformvalidation.formbean.PaymentForm;
import org.o7planning.sbformvalidation.model.PaymentBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import java.util.Optional;
@Component
public class PaymentBeanValidator implements Validator {

	// common-validator library.
	private EmailValidator emailValidator = EmailValidator.getInstance();

	@Autowired
	private PaymentDAO PaymentDAO;

	// The classes are supported by this validator.
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz == PaymentForm.class;
	}

	@Override
	public void validate(Object target, Errors errors) {
		PaymentForm paymentForm = (PaymentForm) target;

		// Check the fields of AppUserForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Card no", "NotEmpty.paymentForm.cardNo");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "CVV", "NotEmpty.paymentForm.cardCvv");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Password", "NotEmpty.paymentForm.password");
		
	}

}