package org.o7planning.sbformvalidation.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity 
@Table(name="payment")
public class PaymentBean 
{
   
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Long paymentId;
    private Integer cardNo;
    private String cardPassword;
    private Integer cardCvv;
    public PaymentBean() 
    {

    }

    public PaymentBean(Long paymentId, Integer cardNo,String cardPassword, Integer cardCvv) 
    {
        super();
        this.paymentId= paymentId;
        this.cardNo = cardNo;
        this.cardPassword= cardPassword;
        this.cardCvv= cardCvv;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Integer getCardNo() {
        return cardNo;
    }

    public void setCardNo(Integer cardNo) {
        this.cardNo=cardNo;
    }
    
    public String getCardPassword() {
        return cardPassword;
    }

    public void setCardPassword(String cardPassword) {
        this.cardPassword = cardPassword;
    }
    
    public Integer getCardCvv() {
        return cardCvv;
    }

    public void setCardCvv(Integer cardCvv) {
        this.cardCvv = cardCvv;
    }
}