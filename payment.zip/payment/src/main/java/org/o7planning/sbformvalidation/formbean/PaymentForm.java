package org.o7planning.sbformvalidation.formbean;

//import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.o7planning.sbformvalidation.model.PaymentBean;

//import org.o7planning.sbformvalidation.model.Category;

public class PaymentForm {

    private Long paymentId;
    private Integer cardNo;
    private String cardPassword;
    private Integer cardCvv;
    
    public PaymentForm() {

    }

    public PaymentForm(Long paymentId, Integer cardNo, String cardPassword, Integer cardCvv) 
    {
        this.paymentId = paymentId;
        this.cardNo = cardNo;
        this.cardPassword= cardPassword;
        this.cardCvv= cardCvv;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Integer getCardNo() {
        return cardNo;
    }

    public void setCardNo(Integer cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardPassword() {
        return cardPassword;
    }

    public void setCardPassword(String cardPassword) {
        this.cardPassword= cardPassword;
    }

    public Integer getCardCvv() {
        return cardCvv;
    }

    public void setCardCvv(Integer cardCvv) {
        this.cardCvv = cardCvv;
    }
}