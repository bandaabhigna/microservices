package org.o7planning.sbformvalidation.service;

import org.o7planning.sbformvalidation.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Service;

import java.util.Optional;

import javax.persistence.LockModeType;
import javax.persistence.QueryHint;

@Service
public interface PayeService 
{
//	Optional<Category> findByitemName(String name);
//	@Lock(value = LockModeType.PESSIMISTIC_WRITE)
//	@QueryHints({@QueryHint(name = "javax.persistence.lock.timeout", value = "3000")})
	Optional<PaymentBean> findBypaymentId(Long id);
}