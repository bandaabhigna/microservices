package org.o7planning.sbformvalidation.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import java.util.ArrayList;
import java.util.Arrays;
//import org.springframework.boot.web.client.RestTemplateBuilder;
import java.util.Collection;
import java.util.Collections;
//import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.o7planning.sbformvalidation.formbean.PaymentForm;
import org.o7planning.sbformvalidation.model.PaymentBean;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public interface PaymentDAO extends CrudRepository<PaymentBean,Long>
{
	
}