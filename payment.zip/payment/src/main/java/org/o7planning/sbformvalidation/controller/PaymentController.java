package org.o7planning.sbformvalidation.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.o7planning.sbformvalidation.dao.*;
import org.o7planning.sbformvalidation.model.*;
import org.o7planning.sbformvalidation.service.*;
import org.o7planning.sbformvalidation.validator.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Optional;

@Controller
public class PaymentController 
{

   @Autowired
   private PaymentDAO paymentDAO;
   
   private PaymentBean pay1=new PaymentBean();

   
   @RequestMapping("/")
   public String viewHome(Model model) {

      return "welcomePage";
   }
   
//   @GetMapping(value = "/viewitems")
//	public ResponseEntity<Iterable<Category>> getitems() 
//	{
//		Iterable<Category> list = categoryDAO.findAll();
//		return new ResponseEntity<Iterable<Category>>(list,HttpStatus.OK);
//	}
   
   @RequestMapping(value = "/payment", method = RequestMethod.GET)
   public String login(Model model)
   {
	      PaymentBean form  = new PaymentBean();
	      model.addAttribute("PaymentBean", form);
	      System.out.println("getii");
	      return "paymentPage";
   }

   
   @RequestMapping(value = "/payment", method = RequestMethod.POST)
   public String submit(Model model, //
	         @ModelAttribute("paymentBean") @Validated PaymentBean paymentBean, //
	         BindingResult result, //
	         final RedirectAttributes redirectAttributes) 
   {
	    		  Iterable<PaymentBean> porder=paymentDAO.findAll();
	    		  for (PaymentBean po : porder) 
	    	       {
	    	            if(po.getCardNo().equals(paymentBean.getCardNo())  &  po.getCardPassword().equals(paymentBean.getCardPassword())  &  po.getCardCvv().equals(paymentBean.getCardCvv()))  
	    	            {
//	    	            	call delete fn of maincontroller here to delete the items
	    	            	RestTemplate restTemplate = new RestTemplate();
	    	    			String status=restTemplate.getForObject("http://localhost:8080/deletecart",String.class);
	    	    			System.out.println("status in payconteoller");
	    	    			System.out.println(status);
	    	    			return "paymentSuccesfulPage";
	    	            }
	    	       }
	    	  return "paymentPage";

   }
   
   @RequestMapping("/paymentSuccessful")
   public String viewloginSuccessful(Model model) 
   {
      return "paymentSuccessfulPage";
   }

}