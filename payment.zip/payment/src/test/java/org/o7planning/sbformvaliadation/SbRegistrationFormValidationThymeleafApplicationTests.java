package org.o7planning.sbformvaliadation;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbRegistrationFormValidationThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
