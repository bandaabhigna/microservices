package org.o7planning.sbformvalidation.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

//import org.o7planning.sbformvalidation.formbean.CategoryForm;
import org.o7planning.sbformvalidation.model.Category;
import org.o7planning.sbformvalidation.model.CategoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public interface CategoryDAO extends CrudRepository<Category, Long>
{
}
//public class CategoryDAO 
//{
//
//    @Autowired
//    private static final Map<Long, Category> USERS_MAP = new HashMap<>();
//
//    static {
//        initDATA();
//    }
//
//    private static void initDATA() 
//    {        
//        Category glass = new Category(1L, "glass",10,200);
//        USERS_MAP.put(glass.getItemId(), glass);
//        Category pipe = new Category(2L, "pipe",120,100);
//        USERS_MAP.put(pipe.getItemId(), pipe);
//        Category cup = new Category(3L, "cup",20,150);
//        USERS_MAP.put(cup.getItemId(), cup);
//        Category bench= new Category(4L, "bench",120,1000);
//        USERS_MAP.put(bench.getItemId(), bench);
//        Category table = new Category(5L, "table",10,500);
//        USERS_MAP.put(table.getItemId(), table);
//        Category flower = new Category(6L, "flower",1000,10);
//        USERS_MAP.put(flower.getItemId(), flower);
//    }
//
//    public Long getMaxItemId() 
//    {
//        long max = 0;
//        for (Long id : USERS_MAP.keySet()) {
//            if (id > max) {
//                max = id;
//            }
//        }
//        return max;
//    }
//
//    public Category findById(Long id) 
//    {
//        Collection<Category> categories = USERS_MAP.values();
//        for (Category u : categories) 
//        {
//            if (u.getItemId().equals(id)) 
//            {
//                return u;
//            }
//        }
//        return null;
//    }
//
//    public Category findItemByItemName(String itemName) 
//    {
//        Collection<Category> categories = USERS_MAP.values();
//        for (Category u : categories) 
//        {
//            if (u.getItemName().equals(itemName)) 
//            {
//            	System.out.println(u);
//            	System.out.println("findbyitemname");
//                return u;
//            }
//        }
//        return null;
//    }
//
//    public void update(Category cat)
//    {
//    	System.out.println("in DAO");
//		Long id;
//		Collection<Category> categories = USERS_MAP.values();
//	        for (Category u : categories) 
//	        {
//	            if (u.getItemName().equals(cat.getItemName())) 
//	            {
//	            	id=u.getItemId();
//	                u.setItemQuantity(u.getItemQuantity()-cat.getItemQuantity());
//	                USERS_MAP.put(id, u);
//	             }
//	        }
//    }
//
//    public Category createItem(CategoryForm form) 
//    {
//        Long itemId = this.getMaxItemId() + 1;
//        Category item = new Category(itemId, form.getItemName(),form.getItemQuantity(), form.getItemPrice());
//
//        USERS_MAP.put(itemId, item);
//        return item;
//    }
//    
//    public List<Category> getItem() {
//        List<Category> list = new ArrayList<>();
//        list.addAll(USERS_MAP.values());
//        return list;
//    }
//    
//    public void updateitem(Category cat)
//    {
//    	System.out.println("in DAO");
//		Long id;
//		Collection<Category> categories = USERS_MAP.values();
//	        for (Category u : categories) 
//	        {
//	            if (u.getItemName().equals(cat.getItemName())) 
//	            {
//	            	id=u.getItemId();
//	                u.setItemQuantity(u.getItemQuantity()-cat.getItemQuantity());
//	                USERS_MAP.put(id, u);
//	             }
//	        }
//    }
//    
//    public void deleteItem(CategoryBean cat) 
//    {
//    	Long id;
//		Collection<Category> categories = USERS_MAP.values();
//	        for (Category u : categories) 
//	        {
//	            if (u.getItemName().equals(cat.getItemName())) 
//	            {
//	            	id=u.getItemId();
//	                USERS_MAP.remove(id);
//	                break;
//	             }
//	        }
//    }
//    
//    public void modifyItem(CategoryBean cat)
//    {
//		Long id;
//		Collection<Category> categories = USERS_MAP.values();
//	        for (Category u : categories) 
//	        {
//	            if (u.getItemName().equals(cat.getItemName())) 
//	            {
//	            	id=u.getItemId();
//	                u.setItemQuantity(cat.getItemQuantity());
//   
//	                USERS_MAP.put(id, u);
//	                break;
//	             }
//	        }
//    }
//
//}