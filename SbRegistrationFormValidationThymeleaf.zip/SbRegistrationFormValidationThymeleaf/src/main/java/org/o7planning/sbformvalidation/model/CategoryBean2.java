package org.o7planning.sbformvalidation.model;

public class CategoryBean2 {
    

    private Long itemId;
    private Integer itemQuantity;
    private Integer itemTotalPrice;

    public CategoryBean2() 
    {

    }

    public CategoryBean2(Long itemId, Integer itemQuantity,Integer itemTotalPrice) 
    {
        super();
        this.itemId = itemId;
        this.itemQuantity=itemQuantity;
        this.itemTotalPrice=itemTotalPrice;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId= itemId;
    }

    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
    
    public Integer getItemTotalPrice() {
        return itemTotalPrice;
    }

    public void setItemTotalPrice(Integer itemTotalPrice) {
        this.itemTotalPrice = itemTotalPrice;
    }
  

}