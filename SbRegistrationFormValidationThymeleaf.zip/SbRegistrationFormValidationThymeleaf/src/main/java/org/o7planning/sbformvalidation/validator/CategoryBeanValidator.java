package org.o7planning.sbformvalidation.validator;


//import org.o7planning.sbformvalidation.dao.AppUserDAO;
//import org.o7planning.sbformvalidation.model.AppUser;
import org.o7planning.sbformvalidation.model.CategoryBean;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class CategoryBeanValidator implements Validator{

	// common-validator library.

//	@Autowired
//	private AppUserDAO appUserDAO;

	// The classes are supported by this validator.
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz == CategoryBean.class;
	}

	@Override
	public void validate(Object target, Errors errors) {
		CategoryBean categoryBean = (CategoryBean) target;

		// Check the fields of AppUserForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemId", "NotEmpty.categoryBean.itemId");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemQuantity", "NotEmpty.categoryBean.itemQuantity");

		
	}

}