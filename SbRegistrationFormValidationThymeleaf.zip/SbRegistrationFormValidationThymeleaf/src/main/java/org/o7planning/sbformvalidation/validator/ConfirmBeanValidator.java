
package org.o7planning.sbformvalidation.validator;

import org.o7planning.sbformvalidation.model.LoginBean;
import org.o7planning.sbformvalidation.model.ConfirmBean;
import org.o7planning.sbformvalidation.dao.AppUserDAO;
import org.o7planning.sbformvalidation.model.AppUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import java.util.Optional;
@Component
public class ConfirmBeanValidator implements Validator {

	// common-validator library.

	@Autowired
	private AppUserDAO appUserDAO;

	// The classes are supported by this validator.
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz == LoginBean.class;
	}

	@Override
	public void validate(Object target, Errors errors) {
		ConfirmBean confirmBean = (ConfirmBean) target;

		// Check the fields of AppUserForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.loginBean.password");

	}

}