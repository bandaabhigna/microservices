package org.o7planning.sbformvalidation.service;

import org.o7planning.sbformvalidation.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface OrService 
{
//	Optional<Category> findByitemName(String name);
	Optional<UserOrder> findByorderId(Long id);
}