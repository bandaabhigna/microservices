package org.o7planning.sbformvalidation.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity 
@Table(name="AppUser")
public class AppUser 
{
   
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Long userId;
    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String Password;
    private Integer isAccess;
    public AppUser() 
    {

    }

    public AppUser(Long userId, String userName, String firstName, String lastName, //
            Integer isAccess, //
            String email, String password) {
        super();
        this.userId = userId;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.Password = password;
        this.isAccess=isAccess;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Integer getUserIsAccess() {
        return isAccess;
    }

    public void setUserIsAccess(Integer isAccess) {
        this.isAccess=isAccess;
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

 //    public List<CategoryBean> getCart()
//    {
//    	return myCart;
//    }
//    
//    public void setCart(List<CategoryBean> cat)
//    {
////    	this.myCart.add(cat);
////    	adding or appending list to list
//    }
//    
//    public void addToCart(CategoryBean cat)
//    {
//        if (this.myCart==null){
//            this.myCart = new ArrayList<CategoryBean>();
//            myCart.add(cat);
//        }
//        else
//        {
//        	this.myCart.add(cat);
//        }
//    }

}