
package org.o7planning.sbformvalidation.validator;

import org.o7planning.sbformvalidation.model.LoginBean;
import org.o7planning.sbformvalidation.dao.AppUserDAO;
import org.o7planning.sbformvalidation.model.AppUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import java.util.Optional;
@Component
public class LoginBeanValidator implements Validator {

	// common-validator library.

	@Autowired
	private AppUserDAO appUserDAO;

	// The classes are supported by this validator.
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz == LoginBean.class;
	}

	@Override
	public void validate(Object target, Errors errors) {
		LoginBean loginBean = (LoginBean) target;

		// Check the fields of AppUserForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userId", "NotEmpty.loginBean.userId");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.loginBean.password");


		if (!errors.hasFieldErrors("userId")) {
			Optional<AppUser> dbUser = appUserDAO.findById(loginBean.getUserId());
			if (dbUser == null) 
			{
				// Username is not available.
				errors.rejectValue("userId", "No.loginBean.userId");
			}
			else
			{
				
			}
		}

		
	}

}