package org.o7planning.sbformvalidation.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.o7planning.sbformvalidation.dao.AppUserDAO;
import org.o7planning.sbformvalidation.dao.UserOrderDAO;
import org.o7planning.sbformvalidation.dao.CategoryDAO;
import org.o7planning.sbformvalidation.formbean.AppUserForm;
import org.o7planning.sbformvalidation.model.*;
import org.o7planning.sbformvalidation.service.*;
import org.o7planning.sbformvalidation.validator.AppUserValidator;
import org.o7planning.sbformvalidation.validator.LoginBeanValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Optional;

@Controller
public class MainController 
{

   @Autowired
   private AppUserDAO appUserDAO;
   
   @Autowired
   private UserOrderDAO userOrderDAO;
   
   @Autowired
   private CategoryDAO categoryDAO;

   @Autowired
	private UserService userService;
   
   @Autowired
	private OrderService orderService;

   private AppUser user1=new AppUser();
   
   private UserOrder userorder1=new UserOrder();

   @Autowired
   private AppUserValidator appUserValidator;
   private LoginBeanValidator loginBeanValidator;
//   @InitBinder
//   
//   protected void initBinder(WebDataBinder dataBinder) {
//      // Form target
//      Object target = dataBinder.getTarget();
//      if (target == null) {
//         return;
//      }
//      if (target.getClass() == AppUserForm.class) {
//         dataBinder.setValidator(appUserValidator);
//      }
//      if(target.getClass()==LoginBean.class)
//      {
//          dataBinder.setValidator(loginBeanValidator);
//      }
//    }

   @RequestMapping("/")
   public String viewHome(Model model) 
   {

      return "welcomePage";
   }

   @RequestMapping("/members")
   public String viewMembers(Model model) {

      Iterable<AppUser> list = appUserDAO.findAll();
      model.addAttribute("members", list);
      return "membersPage";
   }

   @RequestMapping(value = "/register", method = RequestMethod.GET)
   public String viewRegister(Model model) 
   {
      AppUserForm form = new AppUserForm();
      model.addAttribute("appUserForm", form);
      return "registerPage";
   }
   
   @RequestMapping(value = "/register", method = RequestMethod.POST)
   public String saveRegister(Model model, //
         @ModelAttribute("appUserForm") @Validated AppUserForm appUserForm, //
         BindingResult result, //
         final RedirectAttributes redirectAttributes) 
   {
      // Validate result
//      if (result.hasErrors()) 
//      {
//         return "registerPage";
//      }
      AppUser newUser= new AppUser();
//      try {
      	newUser.setUserIsAccess(-1);
         newUser.setFirstName(appUserForm.getFirstName());
         newUser.setLastName(appUserForm.getLastName());
         newUser.setUserName(appUserForm.getUserName());
         newUser.setEmail(appUserForm.getEmail());
         newUser.setPassword(appUserForm.getPassword());
         newUser.setEmail(appUserForm.getEmail());
         appUserDAO.save(newUser);
         
//      }
      // Other error!!
//      catch (Exception e)
//      {
//         model.addAttribute("errorMessage", "Error: " + e.getMessage());
//         return "registerPage";
//      }

      redirectAttributes.addFlashAttribute("flashUser", newUser);
      return "redirect:/registerSuccessful";
   }
   
   @RequestMapping("/registerSuccessful")
   public String viewRegisterSuccessful(Model model) 
   {
      return "registerSuccessfulPage";
   }

   
   @RequestMapping(value = "/login", method = RequestMethod.GET)
   public String login(Model model)
   {
	      LoginBean form  = new LoginBean();
	      model.addAttribute("loginBean", form);
	      return "loginPage";
   }

   
   @RequestMapping(value = "/login", method = RequestMethod.POST)
   public String submit(Model model, //
	         @ModelAttribute("loginBean") @Validated LoginBean loginBean, //
	         BindingResult result, //
	         final RedirectAttributes redirectAttributes) 
   {
	      Optional<AppUser> newuser= null;
	      try {

	    	  if (loginBean != null && loginBean.getUserId() != null & loginBean.getPassword() != null) 
	    	  {
	    	       newuser=appUserDAO.findById(loginBean.getUserId());
	    	       if(newuser.isPresent())
	    	       {
	    	    	   AppUser nuser=newuser.get();
	    	    	   if(nuser==null)
		    	       {
		    	    	   return "loginPage";
		    	       }
	    	    	   if(!nuser.getPassword().equals(loginBean.getPassword()))
		    	       {
		    	    	   return "loginPage";
		    	       }
	    	    	   user1=nuser;
		    	       redirectAttributes.addFlashAttribute("flashUser", nuser);
		    	       return "redirect:/loginSuccessful";
		    	     }
	    	  }
	    		return "loginPage";
	      }
	      // Other error!!
	      catch (Exception e) {
	         model.addAttribute("errorMessage", "Error: " + e.getMessage());
	         return "loginPage";
	      }
   }
   
   @RequestMapping("/loginSuccessful")
   public String viewloginSuccessful(Model model) 
   {
      return "loginSuccessfulPage";
   }

   public Boolean lock()
   {
	   Iterable<AppUser> users=appUserDAO.findAll();
	   for(AppUser u : users)
	   {
		   if(u.getUserIsAccess()!=-1)
		   {
			   return false;
		   }
	   }
	   return true;
   }
   
   @RequestMapping(value = "/items", method = RequestMethod.GET)
   public String viewitems(Model model) 
   {
    	  RestTemplate restTemplate = new RestTemplate();
		Category[] items=restTemplate.getForObject("http://localhost:8081/viewitems",Category[].class);  
		List<Category> list=Arrays.asList(items);
		  List<Category> list2 = new ArrayList<Category>();
		  for(Category c : list)
		  {
			  System.out.println("teri");
			  System.out.println(c.getItemStatus() + " " + c.getItemName());
			  if(c.getItemStatus()==0)
			  {
				  System.out.println("hiiiii");
				  System.out.println(c.getItemName());
				  list2.add(c); 
			  }
		  }
	      model.addAttribute("items", list2);
	      return "itemsPage";
      
   }   
   
   @RequestMapping(value = "/addtocart", method = RequestMethod.GET)
   public String addtocart(Model model)
   {
	   CategoryBean form  = new CategoryBean();
	   model.addAttribute("categoryBean", form);
	   return "addtocart";
   }
   
   @RequestMapping(value = "/addtocart", method = RequestMethod.POST)
   public String addcart(Model model, //
	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, //
	         BindingResult result, //
	         final RedirectAttributes redirectAttributes)
   {
	   RestTemplate restTemplate = new RestTemplate();
		Category[] items=restTemplate.getForObject("http://localhost:8081/viewitems",Category[].class);  
		List<Category> list=Arrays.asList(items);
       Integer s=0;
       for (Category cat : list) 
       {
            if(cat.getItemId().equals(categoryBean.getItemId()))
            {
            	s=1;
            	if(cat.getItemQuantity()>=categoryBean.getItemQuantity())
            	{
            		UserOrder newUserOrder = new UserOrder();
            		newUserOrder.setItemId(categoryBean.getItemId());
            		newUserOrder.setItemQuantity(categoryBean.getItemQuantity());
            		newUserOrder.setItemTotalPrice(cat.getItemPrice()*categoryBean.getItemQuantity());
            		newUserOrder.setUserId(user1.getUserId());
            		user1.setUserIsAccess(1);
            		userOrderDAO.save(newUserOrder);
            		cat.setItemStatus(1);
            		categoryDAO.save(cat);
            		try {
        			    Thread.sleep(10 * 1000);
        			} catch (InterruptedException ie) {
        			    Thread.currentThread().interrupt();
        			}
            		user1.setUserIsAccess(1);
            		userOrderDAO.save(newUserOrder);
            		cat.setItemStatus(0);
            		categoryDAO.save(cat);
//            		lock2
//            		have to decrement in items table also
            		
//            		System.out.println("starting the update");
//            		RestTemplate restTemplate1 = new RestTemplate();
//            		CategoryBean cat1=new CategoryBean();
//            		cat1.setItemId(categoryBean.getItemId());
//            		cat1.setItemQuantity(cat.getItemQuantity()-categoryBean.getItemQuantity());
//            		System.out.println("middle  the update");
//            		restTemplate1.put("http://localhost:8081/updateitems/"+cat1.getItemId(),cat1,CategoryBean[].class);
//            		System.out.println("ending the update");
            		cat.setItemQuantity(cat.getItemQuantity()-categoryBean.getItemQuantity());
            		categoryDAO.save(cat);
            		return "loginSuccessfulPage";
            	}
            	else
            	{
       	         model.addAttribute("Out of stock");
            	}
            }
       }
       if(s==0)
       {
 	         model.addAttribute("Out of stock");
       }
	   return "loginSuccessfulPage";
   }  
   	 
   @RequestMapping(value = "/mycart", method = RequestMethod.GET)
   public String mycart(Model model)
   {
   
	   System.out.println("my cart get");
 	      List<CategoryBean2> list=new ArrayList<CategoryBean2>();
 	      Iterable<UserOrder> uorder=userOrderDAO.findAll();
 	     for (UserOrder uo : uorder) 
 	       {
 	            if(uo.getUserId().equals(user1.getUserId()))
 	            {            		
            		CategoryBean2 categoryBean2=new CategoryBean2();
            		categoryBean2.setItemId(uo.getItemId());
            		categoryBean2.setItemQuantity(uo.getItemQuantity());
            		categoryBean2.setItemTotalPrice(uo.getItemTotalPrice());
 	            	list.add(categoryBean2);
 	            }
 	       }
	      model.addAttribute("items", list);
	      return "mycart";
   }
   
   @RequestMapping(value = "/mycart", method = RequestMethod.POST)
   public String mycart(Model model, @ModelAttribute("categoryBean2") @Validated CategoryBean2 categoryBean2)
   {
	   System.out.println("model");
	   return "confirmPage";
   }
   
   
//   @RequestMapping(value = "/mycart2", method = RequestMethod.POST,  params = "submit")
//   public String mycart3(Model model,
//		   @ModelAttribute("categoryBean2") CategoryBean2 categoryBean2, //
//	        RedirectAttributes redirectAttributes)
//   {
//	   System.out.println("my cart 3 post");
//	   System.out.println(categoryBean2.getItemId());
//	   userorder1.setItemId(categoryBean2.getItemId());
//	   userorder1.setItemQuantity(categoryBean2.getItemQuantity());
//	   userorder1.setItemTotalPrice(categoryBean2.getItemTotalPrice());
//	   userorder1.setUserId(user1.getUserId());
//	   Iterable<UserOrder> uorder=userOrderDAO.findAll();
//	   for (UserOrder uo : uorder) 
//	       {
//	            if(uo.getUserId().equals(userorder1.getUserId()))
//	            {            		
//	            	if(uo.getItemId().equals(userorder1.getItemId()))
//	            	{
//	            		if(uo.getItemQuantity().equals(userorder1.getItemQuantity()))
//	            		{
//	            			if(uo.getItemTotalPrice().equals(userorder1.getItemTotalPrice()))
//		            		{
//		            			userorder1.setOrderId(uo.getOrderId());
//		            		}
//	            		}
//	            	}
//	            }
//	       }	   
//	   redirectAttributes.addFlashAttribute("flashUserOrder", userorder1);
//	   System.out.println("hey");
//	   System.out.println(userorder1.getItemId());
//	   return "redirect/confirmPage";
//   }
   
   
   @RequestMapping(value = "/mycartconfirm", method = RequestMethod.GET)
   public String confirm(Model model, @ModelAttribute("flashOrder") String flashOrder)
   {
	   System.out.println("my cart confirm get");
	   ConfirmBean form  = new ConfirmBean();
	   model.addAttribute("confirmBean", form);
	   return "confirmPage";
   }
   
   @RequestMapping(value = "/mycartconfirm", method = RequestMethod.POST)
   public String confirm(Model model, //
	         @ModelAttribute("confirmBean") @Validated ConfirmBean confirmBean,//
	         BindingResult result, //
	         RedirectAttributes redirectAttributes) 
   {
	   System.out.println("my cart confirm post");
	   if(confirmBean.getPassword()==user1.getPassword())
	   {
		   System.out.println("checked ");
		   RestTemplate restTemplate = new RestTemplate();
			String status=restTemplate.getForObject("http://localhost:8082/payment",String.class);  
			System.out.println(status);
			if(status=="Success")
			{
//				delete in mycart or mycart to myorder
//				decrease you amount balance 
			}
		   return "mycart";  //name of method
	   }
		System.out.println("mycart");
		return "mycart";
   }
   
   @RequestMapping(value = "/deletecart", method = RequestMethod.GET)
   public String pay(Model model)
   {
	   System.out.println("orginal aying");
	   List<CategoryBean2> list=new ArrayList<CategoryBean2>();
	     Iterable<UserOrder> uorder=userOrderDAO.findAll();
	     for (UserOrder uo : uorder) 
	       {
	            if(uo.getUserId().equals(user1.getUserId()))
	            {            
	            	System.out.println(uo.getOrderId());
	            	userOrderDAO.deleteById(uo.getOrderId());
	            }
	       }
//	      model.addAttribute("items", list);
	      return "mycart";
	   
	   
	
//	      
//	      @RequestMapping(value = "/deleteitems", method = RequestMethod.POST)
//	      public String deleteitems(Model model, //
//	    	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, BindingResult result, final RedirectAttributes redirectAttributes) 
//	    	   {
//	    	  cat2.setItemStatus(0);
//	    	  categoryDAO.deleteById(categoryBean.getItemId());
//	    	  Iterable<Category> list = categoryDAO.findAll();
//	    	     model.addAttribute("viewitems", list);
//	    	   return "membersPage";
//	      } 
	   
//	   
//	   RestTemplate restTemplate = new RestTemplate();
//		String status=restTemplate.getForObject("http://localhost:8082/payment",String.class);
//		System.out.println("status");
//		System.out.println(status);
////		delete the mycart here
//	   return "mycart";
   }
   
   
  
}