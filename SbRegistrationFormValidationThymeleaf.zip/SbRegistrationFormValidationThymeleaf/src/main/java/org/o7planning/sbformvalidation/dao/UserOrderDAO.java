package org.o7planning.sbformvalidation.dao;

import org.springframework.data.repository.CrudRepository;

import org.o7planning.sbformvalidation.model.UserOrder;
import org.springframework.stereotype.Repository;

@Repository
public interface UserOrderDAO extends CrudRepository<UserOrder,Long>
{
	
}