package org.o7planning.sbformvalidation.model;

public class ConfirmBean {

	  private String password;

	  public ConfirmBean()
	  {
		  
	  }
	  public ConfirmBean(String password) {
	        this.password = password;

	    }
	 
	  public String getPassword() {
	    return password;
	  }

	  public void setPassword(String password) {
	    this.password = password;
	  }

	}