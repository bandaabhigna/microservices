package org.o7planning.sbformvalidation.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

//import java.awt.PageAttributes.MediaType;
//import java.net.http.HttpHeaders;

//import org.springframework.boot.web.client.RestTemplateBuilder;
//import org.springframework.http.MediaType;
//import org.springframework.http.converter.HttpMessageConverter;
//import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

//import org.springframework.http.HttpHeaders;
import java.util.ArrayList;
import java.util.Arrays;
//import org.springframework.boot.web.client.RestTemplateBuilder;
import java.util.Collection;
import java.util.Collections;
//import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.o7planning.sbformvalidation.formbean.AppUserForm;
import org.o7planning.sbformvalidation.model.AppUser;
import org.o7planning.sbformvalidation.model.Category;
import org.o7planning.sbformvalidation.model.CategoryBean;
import org.springframework.http.HttpEntity;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public interface AppUserDAO extends CrudRepository<AppUser,Long>
{
	
}
//public class AppUserDAO {
//
//    private static final Map<Long, AppUser> USERS_MAP = new HashMap<>();
//
//    static {
//        initDATA();
//    }
//
//    private static void initDATA() {
//    	
////    	new AppUser(userId, form.getUserName(), //
////                form.getFirstName(), form.getLastName(), false, //
////                form.getGender(), form.getEmail(), form.getCountryCode(), //
////                form.getPassword(), form.getCart());
//       
//        AppUser tom = new AppUser(1L, "tom", "Tom", "Tom", //
//                false, Gender.MALE, "tom@waltdisney.com", "US","tom",null);
//
//        AppUser jerry = new AppUser(2L, "jerry", "Jerry", "Jerry", //
//                true, Gender.MALE, "jerry@waltdisney.com", "US","jerry",null);
//        
//        AppUser nithya = new AppUser(3L, "nithya", "nithya", "nithya", //
//                true, Gender.FEMALE, "psaaho.saaho@gmail.com",  "US","nithya",null);
//
//        
//
//        USERS_MAP.put(tom.getUserId(), tom);
//        USERS_MAP.put(jerry.getUserId(), jerry);
//        USERS_MAP.put(nithya.getUserId(), nithya);
//    }
//
//    public Long getMaxUserId() {
//        long max = 0;
//        for (Long id : USERS_MAP.keySet()) {
//            if (id > max) {
//                max = id;
//            }
//        }
//        return max;
//    }
//
//        public AppUser findAppUserByUserName(String userName) {
//        Collection<AppUser> appUsers = USERS_MAP.values();
//        for (AppUser u : appUsers) {
//            if (u.getUserName().equals(userName)) {
//                return u;
//            }
//        }
//        return null;
//        }
//   
////        public AppUser findAppUserByUserId(Long id) {
////            Collection<AppUser> appUsers = USERS_MAP.values();
////            for (AppUser u : appUsers) {
////                if (u.getUserId().equals(id)) {
////                    return u;
////                }
////            }
////            return null;
////            }
//        
//        
//    public AppUser findAppUserByEmail(String email) {
//        Collection<AppUser> appUsers = USERS_MAP.values();
//        for (AppUser u : appUsers) {
//            if (u.getEmail().equals(email)) {
//                return u;
//            }
//        }
//        return null;
//    }
//
//    public List<AppUser> getAppUsers() 
//    {
//        List<AppUser> list = new ArrayList<>();
//        list.addAll(USERS_MAP.values());
//        return list;
//    }
//    
//    public static <T> List<T> castList(Class<? extends T> clazz, Collection<?> c) {
//	    List<T> r = new ArrayList<T>(c.size());
//	    for(Object o: c)
//	      r.add(clazz.cast(o));
//	    return r;
//	}
//
//    public AppUser createAppUser(AppUserForm form) 
//    {
//        Long userId = this.getMaxUserId() + 1;
//        AppUser user = new AppUser(userId, form.getUserName(), //
//                form.getFirstName(), form.getLastName(), false, //
//                form.getGender(), form.getEmail(), form.getCountryCode(), //
//                form.getPassword(), form.getCart());
//
//        USERS_MAP.put(userId, user);
//        return user;
//    }
//    
//    public List<Category> getitems()
//    {
//		RestTemplate restTemplate = new RestTemplate();
//		Category[] items=restTemplate.getForObject("http://localhost:8081/viewitems",Category[].class);  
//		return Arrays.asList(items);
//    }
//
//    public List<CategoryBean> getcart(AppUser user)
//    {
//    	System.out.println("get cart");
//    	return user.getCart();
//    }
//    
//    public void addcart(Category cat, CategoryBean catBean, AppUser user)
//    {
////    	first add those items into my cart
//    	user.addToCart(catBean);
//    	cat.setItemQuantity(catBean.getItemQuantity());
//    }
//
//    	//    	then decrement it there 
////    	html
////    	RestTemplate restTemplate = new RestTemplate();
////    	String name=cat.getItemName();
////    	System.out.println("line2");
////    	System.out.println(cat.getItemQuantity());
////    	System.out.println("http://localhost:8081/viewItems/" +name);
////		restTemplate.put("http://localhost:8081/viewItems/"+name,cat);  
////		System.out.println("line3");
//    	
////    	json    [	
////		RestTemplate restTemplate = new RestTemplate();
////		HttpHeaders headers = new HttpHeaders();
////		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);    
////		headers.setContentType(MediaType.APPLICATION_JSON);
////		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
////    	
////		HttpEntity<Category> requestBody = new HttpEntity<Category>(cat,headers);
////    	System.out.println("line mid");
////    	
////		restTemplate.put("http://localhost:8081/viewitems/"+cat.getItemName()+".json", requestBody,Category.class);
////		String resourceUrl = "http://localhost:8081/viewitems" + "/" + cat.getItemName()+".json";
////		System.out.println(resourceUrl);
////		CategoryBean e = restTemplate.getForObject(resourceUrl, CategoryBean.class);
////    	/]
//		
////		ResponseEntity<Category> responseEntity = restTemplate.exchange("http://localhost:8081/viewItems", HttpMethod.PUT, requestBody, Category.class);
////    }
//}