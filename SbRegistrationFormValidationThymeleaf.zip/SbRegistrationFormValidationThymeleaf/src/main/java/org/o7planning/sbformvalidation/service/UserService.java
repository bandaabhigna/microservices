package org.o7planning.sbformvalidation.service;

import org.o7planning.sbformvalidation.model.*;
import org.o7planning.sbformvalidation.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService implements UsService
{

    @Autowired
    private AppUserDAO  appUserDAO ;

    @Override
    public Optional<AppUser> findByuserId(Long id) 
    {
        return appUserDAO.findById(id);
    }
}