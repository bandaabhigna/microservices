package org.o7planning.sbformvalidation.model;

public class LoginBean {

	  private String userName;
	  private String password;
	  private Long userId;

	  public LoginBean()
	  {
		  
	  }
	  public LoginBean(String userName,String password,Long userId) {
	        this.userName = userName;
	        this.password = password;
	        this.userId=userId;

	    }
	  public Long getUserId() {
	        return userId;
	    }

	    public void setUserId(Long userId) {
	        this.userId = userId;
	    }	
	    public String getUserName() {
	    return userName;
	  }

	  public void setUserName(String userName) {
	    this.userName = userName;
	  }

	  public String getPassword() {
	    return password;
	  }

	  public void setPassword(String password) {
	    this.password = password;
	  }

	}