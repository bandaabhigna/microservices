package org.o7planning.sbformvalidation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="category")
public class Category {
    
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Long itemId;
    private String itemName;
    private Integer itemQuantity;
    private Integer itemPrice;
    private Integer itemStatus;
    private String itemMaintainance;
    public Category() 
    {

    }

    public Category(Long itemId, String itemName, Integer itemQuantity, Integer itemPrice, Integer itemStatus, String itemMaintainance) 
    {
        super();
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemQuantity=itemQuantity;
        this.itemPrice=itemPrice;
        this.itemStatus=itemStatus;
        this.itemMaintainance=itemMaintainance;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
    
    public Integer getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Integer itemPrice) {
        this.itemPrice = itemPrice;
    }
    
    public Integer getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(Integer itemStatus) {
        this.itemStatus = itemStatus;
    }
    
    public String getItemMaintainance() {
        return itemMaintainance;
    }

    public void setItemMaintainance(String itemMaintainance) {
        this.itemMaintainance = itemMaintainance;
    }
    
//    @Override
//    public String toString() {
//        final StringBuilder sb = new StringBuilder("City{");
//        sb.append("id=").append(id);
//        sb.append(", name='").append(name).append('\'');
//        sb.append(", population=").append(population);
//        sb.append('}');
//        return sb.toString();
//    }

}