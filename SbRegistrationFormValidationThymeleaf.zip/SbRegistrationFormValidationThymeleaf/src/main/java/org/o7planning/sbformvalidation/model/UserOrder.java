package org.o7planning.sbformvalidation.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity 
@Table(name="UserOrder")
public class UserOrder
{
    private Long userId;
	
    private Long itemId;
    
	private Integer itemQuantity;
	
	private Integer itemTotalPrice;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long orderId;
	
	
    public UserOrder() 
    {

    }

    public UserOrder(Long userId, Long itemId, Integer itemQuantity,Long orderId) 
    {
        super();
        this.userId = userId;
        this.itemId = itemId;
        this.itemQuantity=itemQuantity;
        this.orderId = orderId;
        this.itemTotalPrice=itemTotalPrice;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }
    
    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
    
    public Integer getItemTotalPrice() {
        return itemTotalPrice;
    }

    public void setItemTotalPrice(Integer itemTotalPrice) {
        this.itemTotalPrice = itemTotalPrice;
    }

    public void deleteAll()
    {
    	
    }
    


}