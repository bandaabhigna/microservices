package org.o7planning.sbformvalidation.validator;

import org.o7planning.sbformvalidation.dao.CategoryDAO;
import org.o7planning.sbformvalidation.formbean.CategoryForm;
import org.o7planning.sbformvalidation.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class CategoryValidator implements Validator 
{


	@Autowired
	private CategoryDAO categoryDAO;

	@Override
	public boolean supports(Class<?> clazz) 
	{
		return clazz == CategoryForm.class;
	}

	@Override
	public void validate(Object target, Errors errors) 
	{
		CategoryForm categoryForm = (CategoryForm) target;

		// Check the fields of CategoryForm.
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemName", "NotEmpty.categoryForm.itemName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemQuantity", "NotEmpty.categoryForm.itemQuantity");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemPrice", "NotEmpty.categoryForm.itemPrice");

//		if (!errors.hasFieldErrors("itemName")) 
//		{
//			Category dbUser = categoryDAO.findByitemName(categoryForm.getItemName());
//			if (dbUser != null) 
//			{
//				errors.rejectValue("itemName", "Duplicate.categoryForm.itemName");
//			}
//		}
	}

}