package org.o7planning.sbformvalidation.formbean;

public class CategoryForm 
{

	private Long itemId;
    private String itemName;
    private Integer itemQuantity;
    private Integer itemPrice;

    public CategoryForm() {

    }

    public CategoryForm(Long itemId, String itemName, Integer itemQuantity, Integer itemPrice) 
    {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemQuantity=itemQuantity;
        this.itemPrice=itemPrice;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
    
    public Integer getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Integer itemPrice) {
        this.itemPrice = itemPrice;
    }
}