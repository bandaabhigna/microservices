package org.o7planning.sbformvalidation.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

import org.o7planning.sbformvalidation.dao.CategoryDAO;
import org.o7planning.sbformvalidation.service.*;
import org.o7planning.sbformvalidation.formbean.CategoryForm;
import org.o7planning.sbformvalidation.model.Category;
import org.o7planning.sbformvalidation.model.CategoryBean;
import org.o7planning.sbformvalidation.validator.CategoryValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.client.RestTemplate;

@Controller 
@RequestMapping(path="/") 
public class CategoryController
{
   
    @Autowired
	private CategoryDAO categoryDAO;
	
    @Autowired
	private CategoryService categoryService;
	
	@Autowired
	private CategoryValidator categoryValidator;
	
	private Category cat2=new Category();

  @RequestMapping("/")
  public String viewHome(Model model) {

     return "welcomePage";
  }
  
  @RequestMapping(value = "/registerItem", method = RequestMethod.GET)
  public String viewRegisterItem(Model model) 
  {
     CategoryForm form = new CategoryForm();
     model.addAttribute("categoryForm", form);
     return "registerPage";
  }

  @RequestMapping(value = "/registerItem", method = RequestMethod.POST)
  public String saveRegisterItem(Model model, //
        @ModelAttribute("categoryForm") @Validated CategoryForm categoryForm, BindingResult result, final RedirectAttributes redirectAttributes) 
  {
     Category newCategory= new Category();
     newCategory.setItemName(categoryForm.getItemName());
     newCategory.setItemPrice(categoryForm.getItemPrice());
     newCategory.setItemQuantity(categoryForm.getItemQuantity());
     newCategory.setItemStatus(0);
     newCategory.setItemMaintainance(null);
     categoryDAO.save(newCategory);
     cat2=newCategory;
     redirectAttributes.addFlashAttribute("flashItem", newCategory);
     return "redirect:/registerSuccessful";
  }
  
  @RequestMapping("/registerSuccessful")
  public String viewRegisterItemSuccessful(Model model) 
  {

     return "registerSuccessful";
  }
  
  @RequestMapping("/viewItems")
  public String viewMembers(Model model) 
  {
	  Iterable<Category> list = categoryDAO.findAll();
	  List<Category> list2 = new ArrayList<Category>();
	  for(Category c : list)
	  {
		  System.out.println("teri");
		  System.out.println(c.getItemStatus() + " " + c.getItemName());
		  if(c.getItemStatus()==0)
		  {
			  System.out.println("hiiiii");
			  System.out.println(c.getItemName());
			  list2.add(c); 
		  }
	  }
	  Iterable<Category> list3=list2;
     model.addAttribute("viewitems", list3);
     return "membersPage";
  }
  
	@GetMapping(value = "/viewitems")
	public ResponseEntity<Iterable<Category>> getitems() 
	{
		Iterable<Category> list = categoryDAO.findAll();
		return new ResponseEntity<Iterable<Category>>(list,HttpStatus.OK);
	}
	
	@RequestMapping("/viewitems/{id}")
    public String findById1(Model model,@PathVariable final Long id)
	{
		Optional<Category> category = categoryDAO.findById(id);
		  if (category.isPresent()) 
		  {
			    Category ncategory= category.get();
			    categoryDAO.save(ncategory);
			    model.addAttribute("item", ncategory);
			     return "individualItemPage";
		  }
		  Iterable<Category> list = categoryDAO.findAll();
		  model.addAttribute("viewitems", list);
		  return "membersPage";
		
    }
	
  @GetMapping("/viewitems/{id}")
  public ResponseEntity<Category> getitemByItemName(@PathVariable(value = "id") Long id)
  {
	  Optional<Category> category = categoryDAO.findById(id);
	  if (category.isPresent()) 
	  {
		    Category ncategory= category.get();
		    categoryDAO.save(ncategory);
		    return new ResponseEntity<Category>(ncategory,HttpStatus.OK);
	  }
	  return null;
  }
	
	
  @RequestMapping(value = "/updateitems", method = RequestMethod.GET)
  public String updateitem(Model model) 
  {
      CategoryBean form = new CategoryBean();
	   model.addAttribute("categoryBean", form);
	   return "updatePage";
  }
  
  @RequestMapping(value = "/updateitems", method = RequestMethod.POST)
  public String updateitems(Model model, //
	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, BindingResult result, final RedirectAttributes redirectAttributes) 
	   {
  
	  Optional<Category> newCategory= categoryDAO.findById(categoryBean.getItemId());
	  if (newCategory.isPresent()) 
	  {
		    Category category= newCategory.get();
//		    lock
		    category.setItemQuantity(categoryBean.getItemQuantity());
		    category.setItemStatus(1);
		    category.setItemMaintainance("Please wait for 10 seconds. This particular item is undergoing changes ");
		    categoryDAO.save(category);
		    System.out.println("hi");
		    System.out.println(category);
		    try {
			    Thread.sleep(10 * 1000);
			} catch (InterruptedException ie) {
			    Thread.currentThread().interrupt();
			}
		    category.setItemStatus(0);
		    category.setItemMaintainance(null);
		    categoryDAO.save(category);
		    System.out.println("hi2");
		    System.out.println(category);
	  Iterable<Category> list = categoryDAO.findAll();
	     model.addAttribute("viewitems", list);
	   return "membersPage";
	  }
	  else
	  {
		  return "/";
	  }
  } 
  
  @RequestMapping(value = "/updateitems/{id}", method = RequestMethod.PUT)
  public void updateitemsid(@PathVariable("id") String id, Model model, //
	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, BindingResult result, final RedirectAttributes redirectAttributes) 
	   {
	  System.out.println("hi   ");
	  Optional<Category> newCategory= categoryDAO.findById(categoryBean.getItemId());
	  if (newCategory.isPresent()) 
	  {
		    Category category= newCategory.get();
//		    lock
		    category.setItemQuantity(categoryBean.getItemQuantity());
		    categoryDAO.save(category);
		    
	  Iterable<Category> list = categoryDAO.findAll();
	     model.addAttribute("viewitems", list);
	  
	  }
  } 
 
    
  @RequestMapping(value = "/deleteitems", method = RequestMethod.GET)
  public String deleteitem(Model model) 
  {
	  cat2.setItemStatus(0);
	  CategoryBean form = new CategoryBean();
	   model.addAttribute("categoryBean", form);
	   return "DeletePage";
  }
  
  @RequestMapping(value = "/deleteitems", method = RequestMethod.POST)
  public String deleteitems(Model model, //
	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, BindingResult result, final RedirectAttributes redirectAttributes) 
	   {
	  cat2.setItemStatus(0);
	  categoryDAO.deleteById(categoryBean.getItemId());
	  Iterable<Category> list = categoryDAO.findAll();
	     model.addAttribute("viewitems", list);
	   return "membersPage";
  } 

}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

//@Controller
//public class CategoryController {
//
//   @Autowired
//   private CategoryDAO categoryDAO;
//
//
//   @Autowired
//   private CategoryValidator categoryValidator;
//
//   @InitBinder
//   protected void initBinder(WebDataBinder dataBinder) {
//      // Form target
//      Object target = dataBinder.getTarget();
//      if (target == null) {
//         return;
//      }
//      System.out.println("Target=" + target);
//
//      if (target.getClass() == CategoryForm.class) {
//         dataBinder.setValidator(categoryValidator);
//      }
//   }
//
//   @RequestMapping("/")
//   public String viewHome(Model model) {
//
//      return "welcomePage";
//   }
//   
//   @RequestMapping(value = "/registerItem", method = RequestMethod.GET)
//   public String viewRegisterItem(Model model) 
//   {
//      CategoryForm form = new CategoryForm();
//      model.addAttribute("categoryForm", form);
//      return "registerPage";
//   }
//
//   @RequestMapping(value = "/registerItem", method = RequestMethod.POST)
//   public String saveRegisterItem(Model model, //
//         @ModelAttribute("categoryForm") @Validated CategoryForm categoryForm, BindingResult result, final RedirectAttributes redirectAttributes) 
//   {
//      Category newCategory= null;
//     newCategory = categoryDAO.createItem(categoryForm);
//      redirectAttributes.addFlashAttribute("flashItem", newCategory);
//      return "redirect:/registerSuccessful";
//   }
//   
//   @RequestMapping("/registerSuccessful")
//   public String viewRegisterItemSuccessful(Model model) 
//   {
//
//      return "registerSuccessful";
//   }
//   
//   @RequestMapping("/viewItems")
//   public String viewMembers(Model model) 
//   {
//
//      List<Category> list = categoryDAO.getItem();
//      model.addAttribute("viewitems", list);
//      return "membersPage";
//   }
//
//   @GetMapping(value = "/viewitems")
//   public ResponseEntity<List<Category>> getitems() 
//	   {
//		      List<Category> list = categoryDAO.getItem();
//		      return new ResponseEntity<List<Category>>(list,HttpStatus.OK);
//	   }
//   
//   @GetMapping("/viewitems/{name}")
//   public ResponseEntity<Category> getitemByItemName(@PathVariable(value = "name") String name)
//	      {
//	   System.out.println("get viewitems name");
//	        Category category = categoryDAO.findItemByItemName(name);
//	     System.out.println("get viewitems ending");
//	     System.out.println(category);
//	        return new ResponseEntity<Category>(category,HttpStatus.OK);
//	 }
//  
//   
//   @PutMapping("/viewitems/{name}")
//   public ResponseEntity<Category> updateitem(@PathVariable(value = "name") String name, @RequestBody Category cat)
//   {
//	   System.out.println("this is category upadet fn");
//	   categoryDAO.updateitem(cat);
//	   return new ResponseEntity<Category>(cat,HttpStatus.OK);
//	 }
//   
//   @RequestMapping("/viewItems/{name}")
//   public String viewindividualItems(Model model, @PathVariable(value = "name") String name)
//   {
//	        Category category = categoryDAO.findItemByItemName(name);
//	        model.addAttribute("item", category);
//	        return "individualItemPage";
//	 }
//   
//   @RequestMapping(value = "/deleteitems", method = RequestMethod.GET)
//   public String deleteitem(Model model) 
//   {
////	   Long id = null;
//	  CategoryBean form = new CategoryBean();
//
//	   model.addAttribute("categoryBean", form);
//	   return "DeletePage";
//   }
//   
//   @RequestMapping(value = "/deleteitems", method = RequestMethod.POST)
//   public String deleteitems(Model model, //
//	         @ModelAttribute("categoryBean") @Validated CategoryBean categoryBean, BindingResult result, final RedirectAttributes redirectAttributes) 
//	   {   
//	   categoryDAO.deleteItem(categoryBean);
//	   List<Category> list = categoryDAO.getItem();
//	   model.addAttribute("viewitems", list);
//	   return "membersPage";
//   } 
//   
//   @RequestMapping(value = "/updateitems", method = RequestMethod.GET)
//   public String updateitem(Model model) 
//   {
//       CategoryBean form = new CategoryBean();
//
//	   model.addAttribute("categoryBean", form);
//	   return "updatePage";
//   }
//   
//   @RequestMapping(value = "/updateitems", method = RequestMethod.POST)
//   public String updateitems(Model model, //
//	         @ModelAttribute("categoryBean") CategoryBean categoryBean) 
//	   {   
//	   categoryDAO.modifyItem(categoryBean);
//	   List<Category> list = categoryDAO.getItem();
//	   model.addAttribute("viewitems", list);
//	   return "membersPage";
//   } 
//
//}