package org.o7planning.sbformvalidation.model;

public class CategoryBean {
    

    private Long itemId;
    private Integer itemQuantity;

    public CategoryBean() 
    {

    }

    public CategoryBean(Long itemId, Integer itemQuantity) 
    {
        super();
        this.itemId = itemId;
        this.itemQuantity=itemQuantity;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId= itemId;
    }

    public Integer getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(Integer itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
  

}