package org.o7planning.sbformvalidation.service;

import org.o7planning.sbformvalidation.model.Category;
import org.o7planning.sbformvalidation.model.CategoryBean;
import org.o7planning.sbformvalidation.dao.CategoryDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class CategoryService implements CateService
{

    @Autowired
    private CategoryDAO  categoryDAO ;

    public Category findByitemName(String name) 
    {
    	Iterable<Category> list = categoryDAO.findAll();
    	for (Category u : list) 
          {
              if (u.getItemName().equals(name)) 
              {
                  return u;
              }
          }
          return null;
//        return categoryDAO.(name);
    }
    
    @Override
    public Optional<Category> findByitemId(Long id) {

        return categoryDAO.findById(id);
    }
}